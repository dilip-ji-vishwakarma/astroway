import {
  Box,
  FlexBox,
  InputSelect,
  TextDense
} from '@directsoftware/direct-ui-kit-web'
import { GenericObjectType } from '@/src/type/shared-type'
import { getFromOptionArray } from '@/src/lib/utils'

type SelectPageItemProps = {
  placeholder?: string
  value: number
  onChange: (prop: number) => void
  itemList?: GenericObjectType[]
}

const PER_PAGE_ITEMS = [
  { label: 10, value: 10 },
  { label: 25, value: 25 },
  { label: 50, value: 50 },
  { label: 75, value: 75 },
  { label: 100, value: 100 }
]

export const SelectPerPageItem = ({
  placeholder = 'Select Per Page Record',
  value = 25,
  onChange,
  itemList = PER_PAGE_ITEMS
}: SelectPageItemProps) => {
  return (
    <FlexBox alignItems={'center'} gap={'xs'} style={{ width: 150 }}>
      <Box flex={'1'}>
        <TextDense>Per Page</TextDense>
      </Box>
      <Box>
        <InputSelect
          options={itemList}
          isDense
          isSearchable={false}
          value={getFromOptionArray(PER_PAGE_ITEMS, 'value', value, 'option')}
          onChange={(option: any) => onChange(option.value)}
          placeholder={placeholder}
          inputWidth={'auto'}
          removeBottomSpacer
        />
      </Box>
    </FlexBox>
  )
}
