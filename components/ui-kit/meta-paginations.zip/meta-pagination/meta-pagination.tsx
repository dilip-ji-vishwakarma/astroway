import { useMemo } from 'react'
import { cn } from '@/src/lib/utils'
import {
  Pagination,
  PaginationContent,
  PaginationEllipsis,
  PaginationItem,
  PaginationLink
} from '../../ui/pagination'
import { usePagination } from './hook/use-pagination'
import { SelectPerPageItem } from './toolkit/select-per-page-Item'

type PaginationTypes = {
  total: number
  value: number
  onChange: (prop: number) => void
  siblings?: number
  boundaries?: number
  recordPerPage: number
}

export const MetaPagination = ({
  total,
  siblings = 0,
  boundaries = 1,
  value,
  onChange,
  recordPerPage
}: PaginationTypes) => {
  const totalPages = useMemo(() => {
    if (recordPerPage <= 0) {
      throw new Error('Items per page must be greater than zero.')
    }
    return Math.ceil(total / recordPerPage)
  }, [total, recordPerPage])

  const pagination = usePagination({
    total: totalPages,
    page: value,
    onChange: onChange,
    siblings: siblings,
    boundaries: boundaries
  })

  const changePage = (prop: number) => {
    pagination.setPage(prop)
  }

  return (
    <Pagination className="justify-start">
      <PaginationContent>
        <PaginationItem
          className={cn({
            '  opacity-50 cursor-auto ': value === 1
          })}
        >
          <PaginationLink onClick={() => pagination.previous()}>
            Previous
          </PaginationLink>
        </PaginationItem>
        {pagination.range.map((item, index) => {
          return (
            <PaginationItem key={index}>
              {item === 'dots' ? (
                <PaginationEllipsis />
              ) : (
                <PaginationLink
                  onClick={() => changePage(item)}
                  key={index}
                  isActive={item === pagination.active}
                >
                  {item}
                </PaginationLink>
              )}
            </PaginationItem>
          )
        })}
        <PaginationItem
          className={cn({ 'opacity-50 cursor-auto': value === totalPages })}
        >
          <PaginationLink onClick={() => pagination.next()}>
            Next
          </PaginationLink>
        </PaginationItem>
      </PaginationContent>
    </Pagination>
  )
}

MetaPagination.PerPage = SelectPerPageItem
